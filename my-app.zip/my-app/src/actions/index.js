export const FETCH_POST = "FETCH_POST";
export const BUY_POST = "BUY_POST";
export const SELL_POST = "SELL_POST";


